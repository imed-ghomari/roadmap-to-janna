---
type: process
initiative:
  - "[[Initiatives/worship/Zakat and charity and selflessness|Zakat and charity and selflessness]]"
  - "[[Initiatives/worship/Upholding the right of muslims|Upholding the right of muslims]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Zakat, Charity, and Selflessness](Initiatives/worship/Zakat%20and%20charity%20and%20selflessness.md) and [Upholding the Rights of Muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md).  

* Give gifts when visiting others, or if someone gives you a gift, try to reciprocate with something, even if small.  
* Offer gifts to those you dislike to soften their hearts and promote reconciliation.  
