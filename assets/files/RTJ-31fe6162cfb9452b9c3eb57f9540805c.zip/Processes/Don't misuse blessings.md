---
type: process
initiative:
  - "[[Initiatives/good traits/Gratitude|Gratitude]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Gratitude](Initiatives/good%20traits/Gratitude.md): Using material and immaterial blessings for obedience, not disobedience (for example, use your tongue, eyes, ears, and limbs for Allah's pleasure)
