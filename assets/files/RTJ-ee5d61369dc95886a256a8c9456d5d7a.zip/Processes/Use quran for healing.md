---
type: process
initiative:
- '[[Engaging with the quran]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Engaging with the quran](Initiatives/worship/Engaging%20with%20the%20quran.md): recite the Quran (Fatiha) when ill by putting the hand on the place of affliction
