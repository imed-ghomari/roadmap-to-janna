---
type: process
initiative:
- '[[Following the sunnah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md):

* Drink, sitting down from a cup and breathing 3 times
* Eat slowly with 3 fingers on the ground, and if it's from the same bowl, eat from your side
