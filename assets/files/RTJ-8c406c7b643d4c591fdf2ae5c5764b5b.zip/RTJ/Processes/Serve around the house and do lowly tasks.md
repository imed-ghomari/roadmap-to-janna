---
type: process
initiative:
  - "[[Following the sunnah]]"
  - "[[Managing spouse]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

* Link to [Pride and self admiration and humility](Initiatives/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md): helps you understand your place
* Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md): the Prophet used to help his family
* Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md) and [Managing spouse](Initiatives/worship/Managing%20spouse.md): subject of delegations could be:
	* Cleaning
	* Childcare
	* Cooking
	* Home maintenance
	* Managing finances
	* Planning
	* Scheduling family activities
	* Shopping
	* Transportation
