---
type: process
initiative:
  - "[[Love and contentment]]"
  - "[[Remembering death]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

* Link to [Love and contentment](Initiatives/good%20traits/Love%20and%20contentment.md): Because you love him more, so you love the ones who love him
* Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md): To prepare to be from the seven categories under his shade on the day of judgment.
