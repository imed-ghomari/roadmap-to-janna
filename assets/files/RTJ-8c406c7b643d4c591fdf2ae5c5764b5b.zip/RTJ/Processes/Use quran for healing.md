---
type: process
initiative:
  - "[[Engaging with the quran]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Engaging with the quran](Initiatives/worship/Engaging%20with%20the%20quran.md): recite the Quran (Fatiha) when ill by putting the hand on the place of affliction
