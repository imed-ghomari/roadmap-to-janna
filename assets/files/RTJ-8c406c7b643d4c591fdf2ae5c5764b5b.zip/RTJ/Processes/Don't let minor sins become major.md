---
type: process
initiative:
  - "[[Initiatives/good traits/Repentance|Repentance]]"
due: ""
duration:
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
---

Link to [Repentance](Initiatives/good%20traits/Repentance.md)

Don't persist, belittle or publicize minor sins and be attentive about them in public when being followed
