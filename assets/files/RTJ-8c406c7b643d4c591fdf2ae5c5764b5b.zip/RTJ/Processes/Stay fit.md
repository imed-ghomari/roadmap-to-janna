---
type: process
initiative:
  - "[[Following the sunnah]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md)

Some things to consider: strength training, cardio, stretching, and balancing
