---
type: process
initiative:
  - "[[Praying]]"
  - "[[Upholding the right of muslims]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

* Like to [Praying](Initiatives/worship/Praying.md): Whenever the need arises (rain, eclipse, funeral), or the time is right (taraweeh, eid), try your best to go to these voluntary prayers.
* Link to [Upholding the right of Muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md): It's a Muslim right to join the funeral prayer of a deceased Muslim. (If enough people join, the obligation is removed from other people.)
