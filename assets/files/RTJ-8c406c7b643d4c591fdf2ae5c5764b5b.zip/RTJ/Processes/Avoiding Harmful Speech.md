---
type: process
initiative:
  - "[[Loquaciousness]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

link to [Loquaciousness](Initiatives/bad%20traits/Loquaciousness.md)

Refrain from making ornamentations or exaggerations in speech. Do not use curse words, vulgar language, or obscenities. Avoid songs, poetry, or excessive joking/laughing that contain bad words, bad themes (religion) or ridicule others.
