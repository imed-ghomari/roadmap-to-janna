---
type: process
initiative:
  - "[[Hajj]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Hajj](Initiatives/worship/Hajj.md)
