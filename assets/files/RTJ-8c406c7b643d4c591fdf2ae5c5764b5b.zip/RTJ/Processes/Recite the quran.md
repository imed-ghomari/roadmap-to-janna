---
type: process
initiative:
  - "[[Engaging with the quran]]"
  - "[[Remembering death]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

* Link to [Engaging with the quran](Initiatives/worship/Engaging%20with%20the%20quran.md):
	* Remember that you must read the Quran as much as you can before it is lifted (on the Day of Judgment).
	* Recite with Tajweed, read translation and Tafsir, and apply Tadabur (be on the lookout for how the Quran speaks to you, especially in difficult times).
	* Remember to say Maw3ida before reciting and recognize the power of Allah over him.
* Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md): Read especially Baqara and Imran to have two flocks of birds to protect you on the day of judgment).
