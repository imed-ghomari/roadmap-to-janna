---
type: process
initiative:
  - "[[Asceticism]]"
  - "[[Remembering death]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

* Link to [Asceticism](Initiatives/good%20traits/Asceticism.md): Ask Allah for all your needs, and view seeking help as a means to an end, only when truly necessary. Strive for independence whenever possible. Exceptions include the destitute, the person in debt, and those who have suffered a financial calamity and lost all their wealth.
* Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md): Aspire to be among the first to reach the Prophet's fountain by embodying humility and patience, rejecting preferential treatment, not seeking a position of power, and befriending the marginalized without condescension.
