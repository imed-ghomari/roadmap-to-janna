---
type: process
initiative:
  - "[[Praying]]"
  - "[[Gratitude]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Praying](Initiatives/worship/Praying.md) and [Gratitude](Initiatives/good%20traits/Gratitude.md)

> [!tip]
> 
> 
> If you are already performing the 12 daily sunnah prayers, you can intend one or more of them to be a chukr prayer.
> 

