---
type: process
initiative:
  - "[[Stinginess]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Stinginess](Initiatives/bad%20traits/Stinginess.md)

For example, for obligatory deeds requiring a lot of money (e.g. Hajj)
