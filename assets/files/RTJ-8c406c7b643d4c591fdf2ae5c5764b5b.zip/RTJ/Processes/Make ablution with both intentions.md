---
type: process
initiative:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: true
---

link to [Praying](Initiatives/worship/Praying.md)
