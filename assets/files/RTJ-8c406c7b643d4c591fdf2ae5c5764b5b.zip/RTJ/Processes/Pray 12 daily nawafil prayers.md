---
type: process
initiative:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

link to [Praying](Initiatives/worship/Praying.md)

* 4 before duhr
* 2 after duhr
* 2 after maghrib
* 2 after icha
* 2 before subh
