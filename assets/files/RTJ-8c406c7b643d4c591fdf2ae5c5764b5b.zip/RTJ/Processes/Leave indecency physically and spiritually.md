---
type: process
initiative: []
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: true
---

Link to [Pride and self admiration and humility](Initiatives/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md):

* Cover yourself physically (to the knees and above the nombril for men and the whole body for women).
* Spiritually is linked to filthy/repugnant/obscene saying and actions that you would be ashamed of if known.
