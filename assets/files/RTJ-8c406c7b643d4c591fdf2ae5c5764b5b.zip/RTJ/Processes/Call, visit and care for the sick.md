---
type: process
initiative:
  - "[[Upholding the right of muslims]]"
  - "[[Following the sunnah]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md) and [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md)

* If a family member with whom you have a close relationship (silat Rahim) has recently become sick, call them. If they live nearby, visit them.
* Donate blood every 3 months.
* If a family member is already sick or has been sick for a long time (won't get better), try to call them periodically.

If you want to do more, you can approach a nursing home, a community, or a local clinic to offer assistance. This could involve bringing gifts or running errands for those in need.
