---
type: process
initiative:
  - "[[Reliance]]"
  - "[[Love and contentment]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

* Link to [Love and contentment](Initiatives/good%20traits/Love%20and%20contentment.md): You can supplicate for what you wish and set your own goals. It does not contradict being content. You can have wants and be content with whatever result you get.
* Link to [Reliance](Initiatives/good%20traits/Reliance.md): When supplicating, make sure to set big goals because Allah is the one who will make it possible. He can do anything. Our actions should not be dependent on the means available to us.
