---
type: process
initiative:
  - "[[Love of status and ostentation]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Love of status and ostentation](Initiatives/bad%20traits/Love%20of%20status%20and%20ostentation.md)

If in a high position, perform "unsavory acts" like disregarding manners when eating to lower regard.
