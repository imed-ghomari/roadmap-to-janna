---
type: process
initiative:
  - "[[Gluttony and lust]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Gluttony and lust](Initiatives/bad%20traits/Gluttony%20and%20lust.md)

This can be done by eating slowly and stopping before feeling full
