---
type: process
initiative:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status: not working
detail: false
---

Link to [Praying](Initiatives/worship/Praying.md)

Respond to the call of prayer and say dua at the end to get the intercession of Muhammad on the day of judgment.
