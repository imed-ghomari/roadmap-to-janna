---
type: initiative
dependency: ""
start: ""
KR: <% tp.file.folder() %>
status:
---
