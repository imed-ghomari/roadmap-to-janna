---
type: process
initiative:
  - "[[Initiatives/good traits/Pride and self admiration and humility|Pride and self admiration and humility]]"
  - "[[Initiatives/bad traits/Love of status and ostentation|Love of status and ostentation]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

* Link to [Pride and self admiration and humility](Initiatives/good%20traits/Pride%20and%20self%20admiration%20and%20humility.md): Detach your self-worth from temporary worldly blessings, and don't compare yourself to others, thinking you deserve their blessings. This can be exemplified by not oversharing your good traits or accomplishments.
* Link to [Love of status and ostentation](Initiatives/bad%20traits/Love%20of%20status%20and%20ostentation.md): Don't mistake having high status with god as possessing worldly possessions; this status is determined by your closeness to god.
