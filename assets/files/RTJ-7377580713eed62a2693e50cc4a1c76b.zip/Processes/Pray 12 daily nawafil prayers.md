---
type: process
initiative:
  - "[[Initiatives/worship/Praying|Praying]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

link to [Praying](Initiatives/worship/Praying.md)

* 4 before duhr
* 2 after duhr
* 2 after maghrib
* 2 after icha
* 2 before subh
