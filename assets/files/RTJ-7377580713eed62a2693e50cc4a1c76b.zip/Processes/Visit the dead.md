---
type: process
initiative:
  - "[[Initiatives/good traits/Remembering death|Remembering death]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md)

Visit the dead, supplicate for them, and remember the events of death, the grave, the day of judgment, ​hellfire, and paradise

If they are putting someone on the grave, it is recommended to stay with the deceased for the time it takes to slaughter an animal and shed its skin.
