---
type: process
initiative:
- '[[Managing spouse]]'
- '[[Parenting]]'
- '[[Following the sunnah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Managing Spouse](Initiatives/worship/Managing%20spouse.md): Avoid criticizing or exposing your partner's flaws. Instead, focus on helping the other improve while covering his flaws. The saying "spouse like garment" emphasizes that garments are meant to conceal, not reveal.
* Link to [Parenting](Initiatives/worship/Parenting.md): Overlook mistakes that don't involve sinfulness.
* Link to [Following the Sunnah](Initiatives/worship/Following%20the%20sunnah.md): Emulate the Prophet's behavior. He was known for his silence and refrained from criticizing based on his desires.
