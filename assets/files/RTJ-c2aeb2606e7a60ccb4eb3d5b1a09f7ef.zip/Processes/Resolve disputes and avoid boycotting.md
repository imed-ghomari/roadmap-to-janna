---
type: process
initiative:
  - "[[Initiatives/worship/Upholding the right of muslims|Upholding the right of muslims]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md)

- Actively work to resolve disputes, whether your own or others'. Mediate and intercede to foster reconciliation.
- Avoid prolonged boycotting; do not let it exceed three days.
- Be vigilant about potential fitna (discord or chaos). If the situation escalates beyond resolution, prioritize withdrawing and distancing yourself from it.


