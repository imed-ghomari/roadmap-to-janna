---
type: process
initiative:
  - "[[Initiatives/good traits/Remembering death|Remembering death]]"
  - "[[Initiatives/worship/Upholding the right of muslims|Upholding the right of muslims]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

* Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md): Helping someone in need alongside good intentions and good character are the things that weigh the most.
* Link to [Upholding the right of Muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md): One of the objectives of this activity is:
    * Spending time with the poor
    * Showing kindness to orphans
 
