---
type: process
initiative:
- '[[Upholding the right of muslims]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md)
