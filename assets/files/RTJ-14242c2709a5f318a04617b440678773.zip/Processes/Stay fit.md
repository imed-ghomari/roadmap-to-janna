---
type: process
initiative:
- '[[Following the sunnah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md)

Some things to consider: strength training, cardio, stretching, and balancing
