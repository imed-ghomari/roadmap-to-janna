---
type: process
initiative:
- '[[Stinginess]]'
- '[[Managing spouse]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Stinginess](Initiatives/bad%20traits/Stinginess.md): Spend as needed for yourself (necessity), others (charity, hospitality, protecting honor, services), and building good things.
* Link to [Managing spouse](Initiatives/worship/Managing%20spouse.md):
	* Nafaqa - Spend on clothes and goods with excellence
	* Give her an independent property (room if you don't have a house)
