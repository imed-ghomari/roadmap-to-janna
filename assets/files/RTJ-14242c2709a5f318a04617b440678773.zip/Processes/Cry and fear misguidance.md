---
type: process
initiative:
- '[[Fear and hope]]'
- '[[Remembering death]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* [Fear and Hope](Initiatives/good%20traits/Fear%20and%20hope.md):
	* **For the sinner:**
		* Before committing a sin, avoid having hope of forgiveness. Instead, cultivate fear of punishment to prevent falling into sin. Reflect on the unseen consequences of sins by reading related verses and ahadith.
		* Remember the link between good and bad deeds and how each one will work against the other on the scales.
	* **For the obedient:** Strive for a balance between fear and hope.
* [Remembering Death](Initiatives/good%20traits/Remembering%20death.md): Be like the person who remembers God in private, leading their eyes to flow with tears, to be among those under God's shade on the Day of Qiyama.
