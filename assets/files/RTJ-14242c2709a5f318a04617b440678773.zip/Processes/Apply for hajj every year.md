---
type: process
initiative:
- '[[Hajj]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Hajj](Initiatives/worship/Hajj.md)
