---
type: process
initiative:
- '[[Envy]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Envy](Initiatives/bad%20traits/Envy.md): say Tabaraka Lah or macha'alah when witnessing a blessing.

To avoid this, don't look greedily at what other people possess so you don't desire what they have (status or wealth). You can do this by unfollowing someone wealthy on social media.
