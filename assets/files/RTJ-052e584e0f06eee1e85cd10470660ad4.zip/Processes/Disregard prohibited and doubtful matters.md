---
type: process
initiative:
- '[[Seeking the lawful]]'
- '[[Reliance]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Seeking the lawful](Initiatives/worship/Seeking%20the%20lawful.md):
	* Learn about the prohibited matters (especially the major sins) and avoid them completely.
	* For doubtful or debated matters with different opinions, like music, leave them whenever possible.
* Link to [Reliance](Initiatives/good%20traits/Reliance.md): make sure to stop at the lawful means, even if the unlawful ones seem more reliable at getting results.
