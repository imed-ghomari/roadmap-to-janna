---
type: process
initiative:
- '[[Praying]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Praying](Initiatives/worship/Praying.md)

Respond to the call of prayer and say dua at the end to get the intercession of Muhammad on the day of judgment.
