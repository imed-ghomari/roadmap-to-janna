---
type: process
initiative:
- '[[Gratitude]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Gratitude](Initiatives/good%20traits/Gratitude.md)

Being grateful for the prophet by saying salawat. Here are the multiple occasions where you should send salawat:

* When the prophet is mentioned (at least the first time, which is obligatory)
* In morning and evening supplications
* If you are applying the order in the dua (begin and end)
* During the night and day of jumu3a
