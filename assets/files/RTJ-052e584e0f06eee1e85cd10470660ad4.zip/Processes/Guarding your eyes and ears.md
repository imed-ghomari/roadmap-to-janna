---
type: process
due: ''
duration: null
file: ''
context: ''
waiting: false
dependency: ''
initiative:
- '[[Gluttony and lust]]'
recurrence: ''
start: ''
step: ''
working: false
review: ''
---

* Link to [Gratitude](Initiatives/good%20traits/Gratitude.md): it constitutes the gratitude of the limbs by employing the blessing of the eyes and the ears for obedience, not disobedience.
* Link to [Gluttony and lust](Initiatives/bad%20traits/Gluttony%20and%20lust.md): one should avoid intentionally looking at prohibited content, whether in the company of others or while consuming online content.
