---
type: initiative
designed: false
dependency: ""
waiting: false
start: ""
KR: <% tp.file.folder() %>
---
