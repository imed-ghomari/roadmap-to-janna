---
type: process
initiative:
  - "[[Initiatives/worship/Praying|Praying]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

link to [Praying](Initiatives/worship/Praying.md)
