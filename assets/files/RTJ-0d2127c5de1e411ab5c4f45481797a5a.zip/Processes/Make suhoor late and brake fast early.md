---
type: process
initiative:
  - "[[Initiatives/worship/Fasting|Fasting]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Fasting](Initiatives/worship/Fasting.md): break with light food so you can wake up easily to pray tahajjud
