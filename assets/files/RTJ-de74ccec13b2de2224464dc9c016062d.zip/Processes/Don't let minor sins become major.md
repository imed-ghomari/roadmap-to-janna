---
type: process
initiative:
  - "[[Initiatives/good traits/Repentance|Repentance]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Repentance](Initiatives/good%20traits/Repentance.md)

Don't persist, belittle or publicize minor sins and be attentive about them in public when being followed
