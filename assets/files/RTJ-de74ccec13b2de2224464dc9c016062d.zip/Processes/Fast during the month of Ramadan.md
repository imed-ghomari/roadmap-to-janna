---
type: process
initiative:
- '[[Fasting]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

link to [Fasting](Initiatives/worship/Fasting.md)

And if you have any missed days, make them up before the next Ramadan.
