---
type: process
initiative:
  - "[[Initiatives/bad traits/Gluttony and lust|Gluttony and lust]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Gluttony and lust](Initiatives/bad%20traits/Gluttony%20and%20lust.md):

* Avoid being alone with the opposite gender, also avoid unnecessary conversation (small talk)
* Avoid doubtful content that displays unnecessary nudity, and avoid looking at the opposite gender in an inappropriate manner
