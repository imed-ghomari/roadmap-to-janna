---
type: process
initiative:
  - "[[Initiatives/worship/Seeking the lawful|Seeking the lawful]]"
  - "[[Initiatives/good traits/Reliance|Reliance]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

* Link to [Seeking the lawful](Initiatives/worship/Seeking%20the%20lawful.md): can be applied to music.. etc. Only seek when absolutely necessary, and leave them whenever you can.
* Link to [Reliance](Initiatives/good%20traits/Reliance.md): make sure to stop at the lawful means, even if the unlawful ones seem more reliable at getting results.
