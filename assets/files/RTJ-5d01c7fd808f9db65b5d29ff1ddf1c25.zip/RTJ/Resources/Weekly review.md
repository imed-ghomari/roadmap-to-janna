> [!note] How to perform the review
> 
> Go through the questions below and check whether you performed each process consistently. You can respond directly if you are familiar with the linked domains and processes. Otherwise, review the details before answering. Note any areas where you fell short — those will be your focus for the week.
> 

## Actions Done at Specific times

* Did you perform your worship actions ([praying](Objective/worship/Praying.md), [zakat](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md), [fasting](Objective/worship/Fasting.md), [hajj](Objective/worship/Hajj.md), [reciting with the Quran](Objective/worship/Engaging%20with%20the%20quran.md), and [daily supplication](Processes/Say%20morning,%20evening%20and%20before%20sleeping%20supplications.md)) secretly, correctly, on time, and [without ostentation](Processes/Combat%20ostentation%20during%20worship.md), sincerely for Allah?
* Did you try to perform [voluntary worship actions](Processes/Level%20up%20worship.md) (e.g., praying, fasting) according to what you could do?
* When you encountered actions that were done in a certain way by the Prophet (peace be upon him), did you try to [follow him](Objective/worship/Following%20the%20sunnah.md) in it?
* When you were in the company of other people (Muslims, friends, neighbors, and family), did you make sure to [hold your tongue](Objective/bad%20traits/Loquaciousness.md) to the standard set here? Did you [command them for good and forbid their evil](Objective/worship/Commanding%20good%20and%20forbidding%20evil.md)? Did you [uphold their rights](Objective/worship/Upholding%20the%20right%20of%20muslims.md) fully? Did you get [angry](Objective/bad%20traits/Anger.md) when you didn't get your way? Did you get [envious](Objective/bad%20traits/Envy.md) of their blessings? Did you [stop their praise](Objective/bad%20traits/Love%20of%20status%20and%20ostentation.md)? Did you [humble](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md) yourself towards them?
* Did you [seek the company of the righteous and distance yourself from the disobedient](Processes/Hate%20the%20disobedient%20and%20love%20the%20obedient.md)?
* When engaging in sin, did you [stop yourself](Processes/Stop%20yourself%20during%20sin.md) out of fear? And after the sin, did you truly repent by [regretting and preventing](Processes/Regret%20and%20prevent.md) future lapses?
* In your free time, did you [remember Allah](Objective/worship/Remembrance%20of%20allah.md) or seek to [increase your knowledge](Processes/Build%20knowledge%20in%20free%20time.md) to get closer to Him and prepare for future tests?
* Did you have the [right attitude](Processes/Attitude%20in%20affliction.md) when you encountered an affliction?
* Are you [charitable](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md) and [generous](Objective/bad%20traits/Stinginess.md) with your blessings, providing help with wealth, time, and services, especially to your family?
* Did you apply moderation when [eating](Objective/bad%20traits/Gluttony%20and%20lust.md) and [acquiring goods and services](Objective/good%20traits/Asceticism.md)?
* Did you perform all the actions that would [prepare you for the Day of Judgment](Objective/good%20traits/Remembering%20death.md) and its subsequent events?

## Actions Done All the time

1. Were you fearful of committing future sins (either new or persistent in old sins) by:
	* Being patient with the rulings by…
		* Constantly questioning the permissibility of your actions to [remain in lawful](Objective/worship/Seeking%20the%20lawful.md)?
		* Having a [high level of caution](Objective/worship/Seeking%20the%20lawful.md) by not indulging?
	* Remembering continuously the [things that should be feared](Objective/good%20traits/Fear%20and%20hope.md), like mentioning [death](Objective/good%20traits/Remembering%20death.md)?
2. Did you sincerely hope for the forgiveness of your past sins by:
	* [Making istighfar](Objective/good%20traits/Repentance.md) (seeking forgiveness) constantly?
	* Doing good deeds [sincerely](Objective/good%20traits/Sincerity%20and%20truthfulness.md) for Allah while [relying](Objective/good%20traits/Reliance.md) on Him…
		* By saying Bismillah (In Allah's name) and Insha'Allah (If Allah wills)?
		* And by performing them with an excellence mindset?
		* And by making dua (supplication) and focusing on the effort rather than the results?
3. Were you [content](Objective/good%20traits/Love%20and%20contentment.md) with your decree, and did you renew your love for him by realizing his perfection and being continuously [grateful](Objective/good%20traits/Gratitude.md)?