---
status: ''
start: ''
context: ''
sidebar_label: Hate the disobedient and love the obedient
domain:
- '[[Commanding good and forbidding evil|Commanding good and forbidding evil]]'
- '[[Love and contentment|Love and contentment]]'
- '[[Sincerity and truthfulness|Sincerity and truthfulness]]'
- '[[Upholding the right of muslims|Upholding the right of muslims]]'
- '[[Anger|Anger]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

* Link to [Commanding good and forbidding evil](Objective/worship/Commanding%20good%20and%20forbidding%20evil.md): Distinguish between the action and the person. Pray for the person's guidance out of compassion.
* Link to [Love and contentment](Objective/good%20traits/Love%20and%20contentment.md):
	* While we must accept Allah's plan, it doesn't mean we condone the actions of disobedient people.
	* Evaluate your friends, love the ones who love God the most, and distance yourself from the ones who hate God the most. This evaluation is done through their external actions. Also, if you love them, love them mildly because you don't know what might happen in the future.
* Link to [Sincerity and truthfulness](Objective/good%20traits/Sincerity%20and%20truthfulness.md): Avoid untruthful people. Request proof for their claims. Test their sincerity before entrusting them with important matters.
* Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md): Stay away from unsavory individuals and keep the company of the righteous. Don't keep company with people who don't inspire you through their state (actions) or guide you through their speech (advice).
* Link to [Anger](Objective/bad%20traits/Anger.md):
	* You use anger to oppose tyranny and prevent wicked acts and corruption (eg, exploitation, oppression, personal threats, wrongdoing)
	* When you witness impermissible acts being carried out, then you feel anger at such abominations
	* You show a protective sense of jealousy or ghirah regarding your spouse or when your honor and prestige are challenged or injured.

> [!tip] summary
> 
> 
> Evaluate friends based on their actions, associate only with the truthful, prioritizing those who love God, and distance yourself from those who hate Him, which constitutes unsavory company.
> 