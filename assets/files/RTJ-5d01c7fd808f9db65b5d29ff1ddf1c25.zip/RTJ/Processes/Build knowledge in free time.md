---
status: ''
start: ''
context: ''
sidebar_label: Build knowledge in free time
domain:
- '[[Gratitude|Gratitude]]'
- '[[Remembrance of allah|Remembrance of allah]]'
- '[[Love and contentment|Love and contentment]]'
- '[[Fasting|Fasting]]'
- '[[Gluttony and lust|Gluttony and lust]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

* Link to [Gratitude](Objective/good%20traits/Gratitude.md): Use free time to build knowledge, habits, and good deeds in preparation for future hardships.
* Link to [Remembrance of allah](Objective/worship/Remembrance%20of%20allah.md): Engage in religious practices daily, such as learning, watching videos, and listening to podcasts.
* Link to [Love of status and ostentation](Objective/bad%20traits/Love%20of%20status%20and%20ostentation.md): Prioritize religious knowledge over worldly pursuits, focusing on improving your status in the afterlife.
* Link to [Fasting](Objective/worship/Fasting.md): Focus on the spiritual aspect of fasting, rather than just the physical, by remembering Allah in your free time.