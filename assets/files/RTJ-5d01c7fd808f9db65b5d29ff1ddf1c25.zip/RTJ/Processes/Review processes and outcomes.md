---
status: ''
start: ''
context: ''
sidebar_label: Review processes and outcomes
domain:
- '[[Fear and hope|Fear and hope]]'
- '[[Love of status and ostentation|Love of status and ostentation]]'
- '[[Self scrutiny|Self scrutiny]]'
- '[[strategy and execution]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

* Link to [Sincerity and truthfulness](Objective/good%20traits/Sincerity%20and%20truthfulness.md): Maintain even the smallest actions for each process because the intention is more important than the size of the deed. God can make it bigger, and we can't know which good deeds Allah likes, so we shouldn't belittle anything.
* Link to [Fear and hope](Objective/good%20traits/Fear%20and%20hope.md): Ensure consistency in actions, avoid wishful thinking, and link hope to concrete actionable steps.
* Link to [Love of status and ostentation](Objective/bad%20traits/Love%20of%20status%20and%20ostentation.md): You consistently do good. You don't stop when other people stop, and you don't stop if others discourage you or attack you. You are not doing it for them; you are doing it for the sake of God.
* Link to [Self scrutiny](Objective/good%20traits/Self%20scrutiny.md):
	* Evaluate the sincerity of the worship acts, and if you didn't do some of them, overload yourself with nawafil, recitation, and adkar.
	* If you can't do a process related to a bad trait, punish yourself by fasting or giving to charity.

> [!tip] summary
> 
> 
> Review the processes and outcomes below to check intentions and consistency of good deeds, compare processes with their domain outcomes, and punish yourself for neglecting them with voluntary worship.
> 