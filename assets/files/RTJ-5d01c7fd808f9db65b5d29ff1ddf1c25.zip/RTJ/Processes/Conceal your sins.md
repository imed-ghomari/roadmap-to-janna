---
status: ''
start: ''
context: ''
sidebar_label: Conceal your sins
domain:
- '[[Love of status and ostentation|Love of status and ostentation]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

- Link to [Love of status and ostentation](Objective/bad%20traits/Love%20of%20status%20and%20ostentation.md): Don't confuse not seeking status with revealing your sins. You should conceal your sins because Allah shielded you, but don't make it appear as if you are better than what you seem, either. If you publicize your sins, Allah will not cover you on the day of qiyama.
- Link to [Repentance](Objective/good%20traits/Repentance.md): Don't persist, belittle, or publicize minor sins, and be attentive about them in public when being followed