---
status: ''
start: ''
context: ''
sidebar_label: Pray in the mosque
domain:
- '[[Praying|Praying]]'
- '[[Remembering death|Remembering death]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

Link to [Praying](Objective/worship/Praying.md) and [Remembering death](Objective/good%20traits/Remembering%20death.md)

It depends on the Islamic schools of thought, but the [most common view](https://seekersguidance.org/answers/prayer/what-is-the-majority-opinion-on-congregational-prayer/) is that congregational prayer is recommended, not mandatory. Nonetheless, it is highly recommended to engage in congregational prayer whenever possible.

Attend the mosque for prayers, particularly during dawn (fajr) and evening (isha) prayers when the natural light is dim. Additionally, whenever you hear the call to prayer (athan) while traveling, try to stop at a nearby mosque and offer prayer.

This process is meant to bring me closer to the person whose heart is attached to the mosque, to be in God's shade on the Day of Judgment.