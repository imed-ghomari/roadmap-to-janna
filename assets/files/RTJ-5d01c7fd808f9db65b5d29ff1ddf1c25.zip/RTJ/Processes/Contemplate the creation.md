---
status: ''
start: ''
context: ''
sidebar_label: Contemplate the creation
domain:
- '[[Love and contentment|Love and contentment]]'
- '[[Remembrance of allah|Remembrance of allah]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

* Link to [Love and contentment](Objective/good%20traits/Love%20and%20contentment.md): Reflect on the world and its attributes, and recognize that Allah possesses the qualities of the people y ou admire, but on a scale that surpasses humans. He is the source of all goodness and beauty.
* Link to [Remembrance of allah](Objective/worship/Remembrance%20of%20allah.md): Contemplate Allah's creations by observing nature and the beauty of this world. You can do this through documentaries or exploring places with natural surroundings.