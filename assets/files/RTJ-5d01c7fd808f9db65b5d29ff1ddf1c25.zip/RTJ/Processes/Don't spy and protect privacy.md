---
status: ''
start: ''
context: ''
sidebar_label: Don't spy and protect privacy
domain:
- '[[Commanding good and forbidding evil|Commanding good and forbidding evil]]'
- '[[Upholding the right of muslims|Upholding the right of muslims]]'
- '[[Parenting|Parenting]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

* Link to [Commanding good and forbidding evil](Objective/worship/Commanding%20good%20and%20forbidding%20evil.md): Avoid spying on others to identify and prevent wrongdoing.
* Link to [Upholding the right of Muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md):
	* Respect people's privacy. If you overhear a conversation unintentionally, consider covering your ear with headphones.
	* don't enter the house without permission, and stop at three times.
* Link to [Parenting](Objective/worship/Parenting.md): Protect children's privacy. Even within the same household, avoid entering their room without permission and give them space to be alone.