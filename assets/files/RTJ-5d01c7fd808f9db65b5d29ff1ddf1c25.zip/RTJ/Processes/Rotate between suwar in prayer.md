---
status: ''
start: ''
context: ''
sidebar_label: Rotate between suwar in prayer
domain:
- '[[Praying|Praying]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

Link to [Praying](Objective/worship/Praying.md): Changing the surah you pray with during and between the prayers is recommended. For each prayer, there is a sunnah of what surah you should read:

* Short suwar: read from "A-Sharh" to the last for "maghrib" and "assr"
* Medium suwar: read from "Al-a'la" to "Ad-Duha" for "duhr" and "icha"
* Long suwar: read from "9af" to "At-Tariq" for "subh"

To make it easier to track the surah you have read, either use:

* A [Quran application](https://play.google.com/store/apps/details?id=com.greentech.quran&hl=en) and put "pins" in the last surah you have read for each category. (Pins are bookmarks that hold only one item, so they change whenever you select a new surah)
* Or a physical Quran with three placeholders for each category.