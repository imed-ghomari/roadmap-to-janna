---
status: ''
start: ''
context: ''
sidebar_label: Investigate suspicious matters
domain:
- '[[Seeking the lawful|Seeking the lawful]]'
- '[[Parenting|Parenting]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

Link to [Seeking the lawful](Objective/worship/Seeking%20the%20lawful.md) and [Parenting](Objective/worship/Parenting.md) 

Whenever there's suspicion and only then, investigate the lawfulness of the matter before judging. For example, research food before consuming it or asking your local imam.

When in doubt, or if you can't access information in time, seek your heart. True sin is that which disturbs your heart. If accepting something feels wrong or creates unease within you, it's best to avoid it.