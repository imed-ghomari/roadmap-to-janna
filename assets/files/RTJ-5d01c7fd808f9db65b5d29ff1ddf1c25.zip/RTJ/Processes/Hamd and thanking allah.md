---
status: ''
start: ''
context: ''
sidebar_label: Hamd and thanking allah
domain:
- '[[Gratitude|Gratitude]]'
dependency: ''
recurrence: ''
due: ''
type: process
---

link to [Gratitude](Objective/good%20traits/Gratitude.md)

Gratitude of the tongue is publicly acknowledging and thanking God for all blessings, recognizing that all good comes from Him and not from oneself. There are different categories of blessings we should be thankful for:

* For god and his perfect attributes (the giver of blessings)
* Spiritual blessings: current and future accomplishments, the ability to worship, access to Islamic teachings, and closeness to god (the greatest blessing)
* Material blessings (eating, the senses, human helpers, air, water…)
* Immaterial blessings (freedom, safety, health, time, education, the beauty of nature…)
* Being better than other people in spiritual, material, and immaterial blessings

We can express gratitude or say tasbih in salat, in the morning and evening supplications, when seeing someone below you (specific dua), when sneezing, in hardship (specific dua), in prosperity (specific dua) and outside of that, as there are always new blessings and individuals below you.

> [!tip] summary
> 
> 
> Gratitude (tasbih) involves publicly acknowledging and thanking God for all material and immaterial blessings. Regularly recite "Hamdulilah" to express gratitude, especially after prayers, meals, and recognizing blessings.
> 