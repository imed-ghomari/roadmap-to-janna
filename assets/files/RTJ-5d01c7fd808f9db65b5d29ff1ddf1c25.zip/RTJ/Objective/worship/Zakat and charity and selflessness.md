---
status: designed
start: ''
objective: worship well
dependency: ''
sidebar_label: Zakat and charity and selflessness
outcome: ''
type: domain
data: null
---

## Degrees of Giving

Each person gives based on their love for Allah. Most people may not be able to give at the highest levels immediately, but they can gradually progress. Aim to move beyond the minimum required, as giving only the required amount can be seen as stingy:

* **First Level:** The strong—those who give everything they own, keeping nothing for themselves.
* **Second Level:** The moderate—those who don't give everything at once but keep some in case others are in need, not for luxury.
* **Third Level:** The weak—those who only give the obligatory zakat, no more, no less.

## Conditions for Giving

In giving [zakat](Processes/Pay%20zakat.md) and [charity](Processes/Give%20happily.md), keep these five principles in mind:

1. **Secrecy:** Give in private to avoid showing off.
2. **Humility:** Recognize that the recipient is helping you by accepting Allah's due, which purifies you from greed.
3. **Quality:** Give from the best of what you have.
4. **Joyful Spirit:** Give with a happy, sincere attitude.
5. **Purpose:** Direct your charity to where it will have the most impact, such as helping a devout person, supporting a needy family member, assisting a traveler, or anyone who will use it responsibly.

## Types of Charity

Charity can generally be of two types: material resources (like money or items) and acts of service (like sharing knowledge or kindness).

## Opportunities to Give

Consider giving in these situations:

* Preparing for the afterlife:
	* [Create a source of ongoing charity](Processes/Create%20source%20of%20continuous%20charity.md).
	* [Share useful knowledge](Processes/Leave%20useful%20knowledge.md)
* [To remove grudges](Processes/Give%20gifts.md)
* Be flexible with loans, especially if your debtor is facing hardships.