---
type: process
initiative:
- '[[Gluttony and lust]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Gluttony and lust](Initiatives/bad%20traits/Gluttony%20and%20lust.md)

Choose simple, non-luxurious food types, eat even when it's not what you like or if it's cold
