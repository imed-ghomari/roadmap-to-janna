
```set
scope:
  - folder
  - Processes
timestamp: 1732046361104
filter:
  - - working
    - unchecked
    - false
fields:
  - working
  - __bname
grid:
  columnWidths:
    working: 95px
    __bname: 462px
sortby: []

```
