---
type: process
initiative:
  - "[[Initiatives/worship/Praying|Praying]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Praying](Initiatives/worship/Praying.md)

Pray on time and avoid joining the congregation late by being on time. If you missed the prayer due to forgetfulness, make it up immediately. But if you missed the prayer voluntarily (for example, for a long time), don't try to make up every missed prayer; instead, repent and increase your supplementary prayers to seek forgiveness.
