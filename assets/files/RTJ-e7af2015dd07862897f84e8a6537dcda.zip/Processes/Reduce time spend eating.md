---
type: process
initiative:
- '[[Gluttony and lust]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Gluttony and lust](Initiatives/bad%20traits/Gluttony%20and%20lust.md)

Reduce food time by not eating when you're outside, spacing meals, not eating between meals (snacking), and eating once a day or only when you're hungry, not when you think it's time.
