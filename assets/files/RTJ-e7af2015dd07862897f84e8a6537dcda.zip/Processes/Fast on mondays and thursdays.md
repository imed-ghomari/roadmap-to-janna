---
type: process
initiative:
- '[[Fasting]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

link to [Fasting](Initiatives/worship/Fasting.md)

Make sure to create a reminder the day before to make suhoor before the "imsak" time. You can do that easily with prayer apps.
