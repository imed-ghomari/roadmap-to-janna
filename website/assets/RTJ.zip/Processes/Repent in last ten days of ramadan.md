---
type: process
initiative:
  - "[[Initiatives/good traits/Repentance|Repentance]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

link to [Repentance](Initiatives/good%20traits/Repentance.md)

use special dua: "اَللّٰهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّيْ"
