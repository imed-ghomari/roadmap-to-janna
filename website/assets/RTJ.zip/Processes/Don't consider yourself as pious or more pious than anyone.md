---
type: process
initiative:
  - "[[Initiatives/good traits/Pride and self admiration and humility|Pride and self admiration and humility]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Pride and self admiration and humility](Initiatives/good%20traits/Pride%20and%20self%20admiration%20and%20humility.md)

* Don't think of yourself as pious because of your past sins, deeds that might not be accepted, and the bad end that you might have.
* Don't think you're more pious than anyone because you'll never know their intentions and hearts.

This can be applied in conversation, where you might think you can learn from the opinions of the person next to you.
