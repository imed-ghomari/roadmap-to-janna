---
type: process
initiative:
  - "[[Initiatives/worship/Hajj|Hajj]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Hajj](Initiatives/worship/Hajj.md)
