---
type: process
initiative:
  - "[[Initiatives/worship/Reciting the quran|Reciting the quran]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Reciting the quran](Initiatives/worship/Reciting%20the%20quran.md): recite the Quran (Fatiha) when ill by putting the hand on the place of affliction
