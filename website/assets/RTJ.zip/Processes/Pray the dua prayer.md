---
type: process
initiative:
  - "[[Initiatives/worship/Praying|Praying]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Praying](Initiatives/worship/Praying.md): Dua is an important nafil prayer recited after sunrise. Its time ends at noon.
