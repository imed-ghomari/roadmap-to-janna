---
type: process
initiative:
  - "[[Initiatives/worship/Praying|Praying]]"
  - "[[Initiatives/good traits/Reliance|Reliance]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Praying](Initiatives/worship/Praying.md) and [Reliance](Initiatives/good%20traits/Reliance.md)

The steps for istikhara are:

* Make istichara (asking people and seeking advice)
* And then making istikhara (either a prayer or if you can't a supplication) using the dua: اَللّٰهُمَّ إِنِّيْ أَسْتَخِيْرُكَ بِعِلْمِكَ ، وَأَسْتَقْدِرُكَ بِقُدْرَتِكَ ، وَأَسْأَلُكَ مِنْ فَضْلِكَ الْعَظِيْمِ ، فَإِنَّكَ تَقْدِرُ وَلَا أَقْدِرُ ، وَتَعْلَمُ وَلَا أَعْلَمُ ، وَأَنْتَ عَلَّامُ الْغُيُوْبِ. اَللّٰهُمَّ إِنْ كُنْتَ تَعْلَمُ أَنَّ هٰذَا الْأَمْرَ (وَيُسَمِّي حَاجَتَه) خَيْرٌ لِّيْ فِيْ دِيْنِيْ وَمَعَاشِيْ وَعَاقِبَةِ أَمْرِيْ ، فَاقْدُرْهُ لِيْ وَيَسِّرْهُ لِيْ ثُمَّ بَارِكْ لِيْ فِيْهِ ، وَإِنْ كُنْتَ تَعْلَمُ أَنَّ هٰذَا الْأَمْرَ (وَيُسَمِّي حَاجَتَه) شَرٌّ لِّيْ فِيْ دِيْنِيْ وَمَعَاشِيْ وَعَاقِبَةِ أَمْرِيْ ، فَاصْرِفْهُ عَنِّيْ وَاصْرِفْنِيْ عَنْهُ وَاقْدُرْ لِيَ الْخَيْرَ حَيْثُ كَانَ ثُمَّ أَرْضِنِيْ بِهِ
* Then choose objectively the choice that is best for you in regards to the afterlife and keep at it until you can no longer do, due to external barriers, in that case you can switch to the other choice.

> Do it for things you're unsure about and that have an impact on your life
