---
type: process
initiative:
  - "[[Initiatives/good traits/Pride and self admiration and humility|Pride and self admiration and humility]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Pride and self admiration and humility](Initiatives/good%20traits/Pride%20and%20self%20admiration%20and%20humility.md)

Acknowledge your good qualities, accomplishments, and progress, but always attribute them to the One who bestowed them upon you. Think of it like a king granting access to a treasury—the key is yours, but the riches belong to him.

Regarding **progress** specifically, recognize what you have accomplished, as this doesn't contradict humility. Just make sure to thank Allah for his guidance.
