---
type: process
domain:
- '[[Pride and self admiration and humility]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Leave indecency physically and spiritually
---

Link to [Pride and self admiration and humility](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md):

* Cover yourself physically (to the knees and above the nombril for men and the whole body for women).
* Spiritually is linked to filthy/repugnant/obscene saying and actions that you would be ashamed of if known.