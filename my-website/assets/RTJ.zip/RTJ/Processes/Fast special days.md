---
type: process
domain:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Fast special days
---

link to [Fasting](Objective/worship/Fasting.md)

* tasu'a
* 3achura
* shawwal
* dulhijjah
* arafa