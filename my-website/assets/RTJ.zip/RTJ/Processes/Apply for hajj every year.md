---
type: process
domain:
- '[[Hajj]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Apply for hajj every year
---

Link to [Hajj](Objective/worship/Hajj.md)