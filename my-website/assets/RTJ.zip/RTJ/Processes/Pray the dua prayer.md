---
type: process
domain:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Pray the dua prayer
---

Link to [Praying](Objective/worship/Praying.md): Dua is an important nafil prayer that begins after sunrise and ends at noon.