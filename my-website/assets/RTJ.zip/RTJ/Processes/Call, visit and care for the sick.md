---
type: process
domain:
  - "[[Upholding the right of muslims]]"
  - "[[Following the sunnah]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Call, visit and care for the sick
---

Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md) and [Following the sunnah](Objective/worship/Following%20the%20sunnah.md)

* If a family member with whom you have a close relationship (silat Rahim) has recently become sick, call them. If they live nearby, visit them.
* Donate blood every 3 months.
* If a family member is already sick or has been sick for a long time (won't get better), try to call them periodically.

If you want to do more, you can approach a nursing home, a community, or a local clinic to offer assistance. This could involve bringing gifts or running errands for those in need.