---
type: process
domain:
- '[[Remembering death]]'
- '[[Reliance]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Small hopes when planning and saving
---

* Link to [Remembering death](Objective/good%20traits/Remembering%20death.md): Maintain short-term hopes by planning only the immediate morning or evening, and remember death twice a day on these occasions
* Link to [Reliance](Objective/good%20traits/Reliance.md): Be wary of over-planning and over-saving; they might lead you to believe that you can influence the outcome. Focus on acquiring absent benefits or repelling harm that has a high probability of success.

> Remember to approach life with the mindset of a traveler