---
type: process
domain:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Fast during the month of Ramadan
---

link to [Fasting](Objective/worship/Fasting.md)

And if you have any missed days, make them up before the next Ramadan.