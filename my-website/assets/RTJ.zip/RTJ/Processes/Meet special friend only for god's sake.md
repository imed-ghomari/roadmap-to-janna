---
type: process
domain:
  - "[[Love and contentment]]"
  - "[[Remembering death]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Meet special friend only for god's sake
---

* Link to [Love and contentment](Objective/good%20traits/Love%20and%20contentment.md): Because you love him more, so you love the ones who love him
* Link to [Remembering death](Objective/good%20traits/Remembering%20death.md): To prepare to be from the seven categories under his shade on the day of judgment.