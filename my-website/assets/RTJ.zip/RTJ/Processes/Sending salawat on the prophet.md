---
type: process
domain:
- '[[Gratitude]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
sidebar_label: Sending salawat on the prophet
---

Link to [Gratitude](Objective/good%20traits/Gratitude.md)

Express gratitude for the prophet by sending salawat. The more you do this, the closer you will be to him on the Day of Judgment. Here are several occasions when you should send salawat:

* When the prophet is mentioned (at least the first time, which is obligatory)
* In morning and evening supplications
* If you are applying the order in the dua (begin and end)
* During the night and day of jumu3a