---
type: process
domain:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Pray 12 daily nawafil prayers
---

link to [Praying](Objective/worship/Praying.md)

* 4 before duhr
* 2 after duhr
* 2 after maghrib
* 2 after icha
* 2 before subh