---
type: process
domain:
  - "[[Pride and self admiration and humility]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Don't consider yourself as pious or more pious than anyone
---

Link to [Pride and self admiration and humility](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md)

* Avoid thinking you're more pious than anyone else or that you're pious because of your past sins, deeds that might not be accepted, or a bad end that you might have. Recognize your good qualities, accomplishments, and progress, but attribute them to the One who granted them to you, just like a king granting access to a treasury—the key is yours, but the riches belong to him.
* Don't think you're more pious than anyone because you'll never know their intentions and hearts. This can be applied in conversation, where you should think that you can learn from the opinions of the person next to you.