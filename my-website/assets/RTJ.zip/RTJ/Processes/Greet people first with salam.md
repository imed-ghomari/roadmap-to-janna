---
type: process
domain:
- '[[Upholding the right of muslims]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Greet people first with salam
---

Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md)

Let it be the first thing you say to them, and be the one who says salam first, even to strangers, and try to say the full sentence (to earn the full reward)

A simplification of whom you should give salam would be: the one driving should give the salam to the one walking, walking to standing, standing to sitting, sitting to lying down.