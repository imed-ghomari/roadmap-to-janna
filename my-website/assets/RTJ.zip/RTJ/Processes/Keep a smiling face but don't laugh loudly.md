---
type: process
domain:
- '[[Zakat and charity and selflessness]]'
- '[[Following the sunnah]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Keep a smiling face but don't laugh loudly
---

* Link to [Zakat and charity and selflessness](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md): even a smile can be considered a charity
* Link to [Following the sunnah](Objective/worship/Following%20the%20sunnah.md): he used to smile without laughing loudly

> Prolonged amusement can numb your soul, which can lead to foolishness and headlessness