---
type: process
domain:
  - "[[Gluttony and lust]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Decrease the amount of food
---

Link to [Gluttony and lust](Objective/bad%20traits/Gluttony%20and%20lust.md)

This can be done by eating slowly and stopping before feeling full