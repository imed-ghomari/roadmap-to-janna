---
type: process
domain:
- '[[Reliance]]'
- '[[Love and contentment]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Supplicate for what you wish and aim high
---

* Link to [Love and contentment](Objective/good%20traits/Love%20and%20contentment.md): You can supplicate for what you wish and set your own goals. It does not contradict being content. You can have wants and be content with whatever result you get.
* Link to [Reliance](Objective/good%20traits/Reliance.md): When supplicating, make sure to set big goals because Allah is the one who will make it possible. He can do anything. Our actions should not be dependent on the means available to us.