---
type: process
domain:
- '[[Praying]]'
- '[[Gratitude]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Pray chukr nafil prayer
---

Link to [Praying](Objective/worship/Praying.md) and [Gratitude](Objective/good%20traits/Gratitude.md)

> [!tip]
> 
> 
> If you are already performing the 12 daily sunnah prayers, you can intend one or more of them to be a chukr prayer.
> 
