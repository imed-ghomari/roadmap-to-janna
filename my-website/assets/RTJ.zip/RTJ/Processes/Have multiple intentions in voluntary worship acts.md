---
type: process
domain:
  - "[[Sincerity and truthfulness]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Have multiple intentions in voluntary worship acts
---

Link to [Sincerity and truthfulness](Objective/good%20traits/Sincerity%20and%20truthfulness.md)

In voluntary prayers and fasting, have multiple good intentions while doing one supplementary thing to have more rewards