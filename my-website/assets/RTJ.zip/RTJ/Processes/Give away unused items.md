---
type: process
domain:
- '[[Zakat and charity and selflessness]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Give away unused items
---

Link to [Zakat and charity and selflessness](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md): (devices, clothes…)