---
type: process
due: ""
context: ""
dependency: ""
domain:
  - "[[Gratitude]]"
  - "[[Gluttony and lust]]"
recurrence: ""
start: ""
status:
sidebar_label: Guarding your eyes and ears
---

- Link to [Gratitude](Objective/good%20traits/Gratitude.md) : it constitutes the gratitude of the limbs by employing the blessing of the eyes and the ears for obedience, not disobedience.
- Link to [Gluttony and lust](Objective/bad%20traits/Gluttony%20and%20lust.md) : Avoid intentionally looking at prohibited or doubtful content (with nudity), fantasizing (through descriptions or otherwise), being alone with the opposite gender, engaging in unnecessary conversation or looking at the opposite gender inappropriately.