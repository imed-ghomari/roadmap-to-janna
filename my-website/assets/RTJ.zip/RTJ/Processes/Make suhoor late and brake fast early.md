---
type: process
domain:
  - "[[Fasting]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Make suhoor late and brake fast early
---

Link to [Fasting](Objective/worship/Fasting.md): break with light food so you can wake up easily to pray tahajjud