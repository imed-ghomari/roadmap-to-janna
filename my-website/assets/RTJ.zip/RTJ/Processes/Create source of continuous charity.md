---
type: process
domain:
- '[[Zakat and charity and selflessness]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Create source of continuous charity
---

Link to [Zakat and charity and selflessness](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md)

Examples include:

* Building wells to provide access to clean water
* Establishing mosques to facilitate worship
* Funding facilities that will serve the community for years to come
* Supporting education or career development programs

To make it easier, you can donate to a reputable charity organization specializing in these areas. This helps ensure the funds are distributed effectively and reach the most deserving.