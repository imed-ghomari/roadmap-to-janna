---
type: process
domain:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Fast on mondays and thursdays
---

link to [Fasting](Objective/worship/Fasting.md)

Make sure to create a reminder the day before to make suhoor before the "imsak" time. You can do that easily with prayer apps.