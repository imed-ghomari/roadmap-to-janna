---
type: process
domain:
  - "[[Zakat and charity and selflessness]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Leave useful knowledge
---

Link to [Zakat and charity and selflessness](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md)