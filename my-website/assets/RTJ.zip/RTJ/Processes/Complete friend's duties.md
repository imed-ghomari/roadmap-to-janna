---
type: process
domain:
  - "[[Upholding the right of muslims]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Complete friend's duties
---

Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md)

* **Fulfilling their needs:** Helping and fulfilling their requests, whenever possible.
* **Verbal support:** Expressing gratitude, consolation, and encouragement during difficult times.
* **Silence about dislikes:** Refraining from discussing or complaining about non-sinful behavior.
* **Speaking out:** Offering advice, guidance and admonishment.
* **Supplicating for them:** Praying for their well-being, both during life and after death.
* **Loyalty and sincerity:** Being honest, trustworthy, and not exploiting their status or wealth.
* **Avoiding overburdening:** Do not impose on them or make unreasonable requests.