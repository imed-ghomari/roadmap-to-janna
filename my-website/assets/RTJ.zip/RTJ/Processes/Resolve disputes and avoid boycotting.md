---
type: process
domain:
- '[[Upholding the right of muslims]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Resolve disputes and avoid boycotting
---

Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md)

* Actively work to resolve disputes, whether your own or others'. Mediate and intercede to foster reconciliation.
* Avoid prolonged boycotting; do not let it exceed three days.
* Be vigilant about potential fitna (discord or chaos). If the situation escalates beyond resolution, prioritize withdrawing and distancing yourself from it.