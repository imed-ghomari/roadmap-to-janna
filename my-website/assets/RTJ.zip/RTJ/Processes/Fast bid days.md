---
type: process
domain:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Fast bid days
---

link to [Fasting](Objective/worship/Fasting.md)