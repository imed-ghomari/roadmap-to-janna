---
type: process
domain:
  - "[[Praying]]"
  - "[[Upholding the right of muslims]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Pray additional voluntary prayers
---

* Like to [Praying](Objective/worship/Praying.md): Whenever the need arises (rain, eclipse, funeral), or the time is right (taraweeh, eid), try your best to go to these voluntary prayers.
* Link to [Upholding the right of Muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md): It's a Muslim right to join the funeral prayer of a deceased Muslim. (If enough people join, the obligation is removed from other people.)