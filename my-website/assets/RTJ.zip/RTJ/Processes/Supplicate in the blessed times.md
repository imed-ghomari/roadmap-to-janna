---
type: process
domain:
- '[[Reliance]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
sidebar_label: Supplicate in the blessed times
---

Be sure to supplicate during the times that occur most often, as this will help you not miss valuable opportunities.

* daily
	* **In the depths of the night**
	* **After prescribed prayers**
	* **Between the Adhan and Iqamah (the call to prayer and its commencement)**
	* **While prostrating**
* weekly
	* **During specific moments on Fridays**
* sometimes
	* **When rain falls**
	* **When sick**
	* **When drinking Zamzam water**
	* **When hearing the crowing of a rooster**
* yearly
	* **Laylat al-Qadr** (The Night of Decree)