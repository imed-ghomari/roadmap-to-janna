---
type: process
domain:
  - "[[Praying]]"
  - "[[Pride and self admiration and humility]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Focus during prayer
---

* Link to [Pride and self admiration and humility](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md): When standing before god, remember your humble beginnings (sperm drop) and that you carry filth, you produce filth, and you'll become filth when you die
* Link to [Praying](Objective/worship/Praying.md): Here are some ways to stay focused during the prayer:
	* Remember that you're the only one benefiting from this ritual. With this thinking, you can focus better on the acts, the words, and their significance.
	* Focus on making different duas in each rak'ah.
	* Understand the meaning of the words recited, which results in glorifying Allah with fear, hope, and humility.
	* Pray like it's your last: Picture that you're going to die right after because it's a possibility, and this prayer might be your last attempt at salvation.
	* Don't make too many sujud ba3di or 9abli.
	* Use the technique of one of the predecessors: Picture that the angel of death is above you, hell on the left, Janna on the right; you are on the bridge; you can see the ka3ba en face, and picture the greatness of the one you are praying to.

> [!tip] summary
> 
> 
> Remember your humble origins and pray attentively, focusing on different supplications in each portion of your prayers and envisioning each prayer as if it were your last.
> 
