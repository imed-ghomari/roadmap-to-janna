---
type: process
domain:
- '[[Praying]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Respond to call of prayer
---

Link to [Praying](Objective/worship/Praying.md)

Respond to the call of prayer and say dua at the end to get the intercession of Muhammad on the day of judgment.