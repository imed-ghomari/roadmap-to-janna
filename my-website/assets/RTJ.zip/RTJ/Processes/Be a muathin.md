---
type: process
domain:
  - "[[Remembering death]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Be a muathin
---

Link to [Remembering death](Objective/good%20traits/Remembering%20death.md)

Strive to be a muathin (if you can), to be from the ones who have a long neck on the day of qiyama.