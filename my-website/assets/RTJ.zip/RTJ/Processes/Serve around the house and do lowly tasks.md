---
type: process
domain:
- '[[Following the sunnah]]'
- '[[Managing spouse]]'
- '[[Pride and self admiration and humility]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
sidebar_label: Serve around the house and do lowly tasks
---

* Link to [Pride and self admiration and humility](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md): helps you understand your place
* Link to [Following the sunnah](Objective/worship/Following%20the%20sunnah.md): the Prophet used to help his family
* Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md) and [Managing spouse](Objective/worship/Managing%20spouse.md): subject of delegations could be:
	* Cleaning
	* Childcare
	* Cooking
	* Home maintenance
	* Managing finances
	* Planning
	* Scheduling family activities
	* Shopping
	* Transportation