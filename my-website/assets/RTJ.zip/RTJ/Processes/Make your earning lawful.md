---
type: process
domain:
  - "[[Seeking the lawful]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Make your earning lawful
---

Link to [Seeking the lawful](Objective/worship/Seeking%20the%20lawful.md): Don't fear poverty; Allah is the sustainer. If you don't earn lawfully, your supplication won't be accepted.