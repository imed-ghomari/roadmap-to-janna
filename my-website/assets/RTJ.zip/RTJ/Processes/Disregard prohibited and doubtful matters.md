---
type: process
domain:
- '[[Seeking the lawful]]'
- '[[Reliance]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Disregard prohibited and doubtful matters
---

* Link to [Seeking the lawful](Objective/worship/Seeking%20the%20lawful.md):
	* Learn about the prohibited matters (especially the major sins) and avoid them completely.
	* For doubtful or debated matters with different opinions, like music, leave them whenever possible.
* Link to [Reliance](Objective/good%20traits/Reliance.md): make sure to stop at the lawful means, even if the unlawful ones seem more reliable at getting results.