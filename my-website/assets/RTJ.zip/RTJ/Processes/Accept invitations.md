---
type: process
domain:
  - "[[Upholding the right of muslims]]"
  - "[[Following the sunnah]]"
  - "[[Pride and self admiration and humility]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Accept invitations
---

* Link to [Pride and self admiration and humility](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md): Respond to invitations with politeness and humility. Call upon others with gentleness and do not avoid them out of shame.
* Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md): Respect the right of Muslims to attend ceremonies. Muslims have a general right to attend weddings and other events. Declining invitations requires a valid reason.
* Link to [Following the sunnah](Objective/worship/Following%20the%20sunnah.md): The Prophet Muhammad (ﷺ) accepted invitations from all people, even those of humble status.

> [!tip] summary
> 
> 
> Respond to all invitations with kindness and respect the rights of Muslims to attend ceremonies.
> 
