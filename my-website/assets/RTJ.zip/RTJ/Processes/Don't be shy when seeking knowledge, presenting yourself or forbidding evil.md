---
type: process
domain:
- '[[Pride and self admiration and humility]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Don't be shy when seeking knowledge, presenting yourself or forbidding
  evil
---

Link to [Pride and self admiration and humility](Objective/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md)

* Do not be shy when seeking knowledge: Ask questions and do what is necessary to acquire knowledge.
* Do not be shy when presenting yourself for work: Publicize accomplishments with good intentions.
* Do not be shy when forbidding evil and enjoining good: Do not stay silent if you can speak up when things are wrong. Be shy from Allah, not from the creation.
* Do not be shy when telling the truth.