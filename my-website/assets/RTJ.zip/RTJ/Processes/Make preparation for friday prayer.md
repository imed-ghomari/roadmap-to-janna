---
type: process
domain:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Make preparation for friday prayer
---

Link to [Praying](Objective/worship/Praying.md)

Complete Friday prayer by:

* Going early,
* Cleaning the body and beautifying it with perfume
* Reading surat kahf