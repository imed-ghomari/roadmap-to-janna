---
type: process
domain:
- '[[Stinginess]]'
- '[[Managing spouse]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Spend as needed when needed
---

* Link to [Stinginess](Objective/bad%20traits/Stinginess.md): Spend as needed for yourself (necessity), others (charity, hospitality, protecting honor, services), and building good things.
* Link to [Managing spouse](Objective/worship/Managing%20spouse.md):
	* Nafaqa - Spend on clothes and goods with excellence
	* Give her an independent property (room if you don't have a house)