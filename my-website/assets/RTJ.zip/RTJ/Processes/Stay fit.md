---
type: process
domain:
- '[[Following the sunnah]]'
- '[[health management]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
sidebar_label: Stay fit
---

Link to [Following the sunnah](Objective/worship/Following%20the%20sunnah.md)

Some things to consider: strength training, cardio, stretching, and balancing