---
type: process
domain:
- '[[Following the sunnah]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Stay fit
---

Link to [Following the sunnah](Objective/worship/Following%20the%20sunnah.md)

Some things to consider: strength training, cardio, stretching, and balancing