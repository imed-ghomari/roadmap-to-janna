---
type: process
domain:
- '[[Gratitude]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Thank people
---

Link to [Gratitude](Objective/good%20traits/Gratitude.md)

Gratitude of the tongue through thanking people for material and immaterial blessings directly or just by describing their blessing.