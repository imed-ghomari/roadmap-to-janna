---
type: process
domain:
- '[[Stinginess]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Withhold wealth when needed
---

Link to [Stinginess](Objective/bad%20traits/Stinginess.md)

For example, for obligatory deeds requiring a lot of money (e.g. Hajj)