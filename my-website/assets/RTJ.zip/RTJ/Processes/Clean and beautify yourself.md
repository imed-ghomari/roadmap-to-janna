---
type: process
domain:
  - "[[Asceticism]]"
  - "[[Following the sunnah]]"
  - "[[health management]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Clean and beautify yourself
---

* [Asceticism](Objective/good%20traits/Asceticism.md): don't forget to take care of yourself even beyond the minimum to make yourself presentable and clean, for god is beautiful, and He loves beauty
* [Following the sunnah](Objective/worship/Following%20the%20sunnah.md): he used to clip nails in a certain order and try to shower using his method (right side then left side)