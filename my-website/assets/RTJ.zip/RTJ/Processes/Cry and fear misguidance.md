---
type: process
domain:
  - "[[Fear and hope]]"
  - "[[Remembering death]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Cry and fear misguidance
---

* [Fear and Hope](Objective/good%20traits/Fear%20and%20hope.md):
	* **For the sinner:**
		* Before committing a sin, do not rely on hope for forgiveness. Instead, develop a fear of punishment to deter yourself from sinning. Reflect on relevant verses and ahadith about the unseen consequences of sins—think of the horrors of Hellfire; if someone from it appeared here, their terrifying sight alone could caus
		* Remember the link between good and bad deeds and how each one will work against the other on the scales.
	* **For the obedient:** Strive to find a balance between fear and hope. Achieve this by considering the verses from the Quran about both the obedient and the disobedient as applying to you.
* [Remembering Death](Objective/good%20traits/Remembering%20death.md): Be like the person who remembers God in private, leading their eyes to flow with tears, to be among those under God's shade on the Day of Qiyama.
* [Repentance](Objective/good%20traits/Repentance.md): Remember past sins and regret them by fearing their consequences.