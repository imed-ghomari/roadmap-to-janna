---
type: process
domain:
- '[[Engaging with the quran]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Use quran for healing
---

Link to [Engaging with the quran](Objective/worship/Engaging%20with%20the%20quran.md): recite the Quran (Fatiha) when ill by putting the hand on the place of affliction