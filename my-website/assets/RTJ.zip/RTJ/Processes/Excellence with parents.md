---
type: process
domain:
- '[[Upholding the right of muslims]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Excellence with parents
---

Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md)

* If your parents are alive, obey them and treat them kindly by having a friendly relationship and engaging in activities with them (especially your mother). Do not treat them like other people; do your utmost best for them.
* If your parents are dead, make sure to repay their debts to the people (either money or forgiveness) and their debt to God (Hajj or fasting), honor their friends, and supplicate for them to increase their status in the hereafter.