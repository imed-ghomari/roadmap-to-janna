---
type: process
domain:
  - "[[Envy]]"
  - "[[Managing spouse]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Give the spouse freedom but have healthy jealousy
---

* Link to [Envy](Objective/bad%20traits/Envy.md): Good envy or jealousy is to be jealous over your spouse
* Link to [Managing spouse](Objective/worship/Managing%20spouse.md), in regards to women, give her freedom in:
	1. Her money (spend as she likes)
	2. She can have a job given that she takes care of her side of the obligations
	3. Observing moderation in jealousy (not being unmindful of the first steps of a destructive end but not going overboard with suspicion either)