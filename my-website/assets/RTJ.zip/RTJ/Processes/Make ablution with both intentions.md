---
type: process
domain:
- '[[Praying]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Make ablution with both intentions
---

link to [Praying](Objective/worship/Praying.md)