---
type: process
domain:
  - "[[Praying]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Make ablution with both intentions
---

link to [Praying](Objective/worship/Praying.md)