---
type: process
domain:
- '[[Envy]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Help people who you envy
---

Link to [Envy](Objective/bad%20traits/Envy.md): Help people who are more blessed, be humble with them, praise them, and feel joy for them (if you can't help them physically, pray for them).