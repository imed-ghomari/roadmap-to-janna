---
type: process
domain:
- '[[Zakat and charity and selflessness]]'
- '[[Upholding the right of muslims]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Give gifts
---

Link to [Zakat, Charity, and Selflessness](Objective/worship/Zakat%20and%20charity%20and%20selflessness.md) and [Upholding the Rights of Muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md).

* Give gifts when visiting others, or if someone gives you a gift, try to reciprocate with something, even if small.
* Offer gifts to those you dislike to soften their hearts and promote reconciliation.