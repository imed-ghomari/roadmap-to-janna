---
type: process
domain:
  - "[[Remembering death]]"
  - "[[Upholding the right of muslims]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
sidebar_label: Help orphans or people in need periodically
---

* Link to [Remembering death](Objective/good%20traits/Remembering%20death.md): Helping someone in need alongside good intentions and good character are the things that weigh the most.
* Link to [Upholding the right of Muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md): One of the objectives of this activity is:
	* Spending time with the poor
	* Showing kindness to orphans. The Prophet said: 'I and the one who sponsors an orphan will be like this in Paradise' (indicating two fingers close together).