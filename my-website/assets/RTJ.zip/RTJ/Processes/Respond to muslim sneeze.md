---
type: process
domain:
- '[[Upholding the right of muslims]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
status: ''
detail: null
sidebar_label: Respond to muslim sneeze
---

Link to [Upholding the right of muslims](Objective/worship/Upholding%20the%20right%20of%20muslims.md)