---
type: process
domain:
  - "[[Anger]]"
  - "[[Following the sunnah]]"
due: ""
recurrence: ""
start: ""
context: ""
dependency: ""
status:
success:
sidebar_label: Have mercy in business dealings
---

Link to [Anger](Objective/bad%20traits/Anger.md) and [Following the sunnah](Objective/worship/Following%20the%20sunnah.md)

Because this is where people demand their rights most often, being merciful is very praiseworthy.