---
type: process
initiative:
- '[[Gratitude]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Gratitude](Initiatives/good%20traits/Gratitude.md)

Gratitude of the tongue through thanking people for material and immaterial blessings directly or just by describing their blessing.