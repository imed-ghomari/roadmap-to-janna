---
type: process
initiative:
- '[[Gratitude]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Gratitude](Initiatives/good%20traits/Gratitude.md)

Gratitude of the tongue through thanking people for material and immaterial blessings directly or just by describing their blessing.
