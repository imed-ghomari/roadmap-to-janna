---
type: process
initiative:
- '[[Zakat and charity and selflessness]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Zakat and charity and selflessness](Initiatives/worship/Zakat%20and%20charity%20and%20selflessness.md)

If your savings have reached 85 grams of gold or 595 grams of silver (calculate the equivalent in your currency) and one lunar year (354 days) has passed since the savings reached this threshold, you are required to pay 2.5% of your savings as Zakat.

If the amount of your savings falls below the threshold during the year, no Zakat is due.

> To simplify the process, mark the date when your savings reach the threshold. When a lunar year has passed since that date, calculate 2.5% of the total amount in your savings and donate it for Zakat. It is an acceptable and recommended practice, even if this means paying Zakat in advance for some savings periods.