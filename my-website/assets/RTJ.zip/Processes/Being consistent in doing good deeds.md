---
type: process
initiative:
  - "[[Initiatives/good traits/Sincerity and truthfulness|Sincerity and truthfulness]]"
  - "[[Initiatives/worship/Upholding the right of muslims|Upholding the right of muslims]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

* Link to [Sincerity and truthfulness](Initiatives/good%20traits/Sincerity%20and%20truthfulness.md): Because the intention is more important than the size of the deed, god can make it bigger, and we can't know which good deeds Allah likes, so we shouldn't belittle anything
* Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md): It's the right of Muslims to do good to all people, regardless of their behavior.
 
