---
type: process
initiative:
- '[[Upholding the right of muslims]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md)

To uphold the rights of Muslim neighbors, it is essential to:

* Refrain from causing harm and avoid lengthy conversations.
* Overlook their faults and cover up their shortcomings.
* Initiate good, greet them first, and be gentle.
* Visit during illness, provide comfort during affliction and assist their families in their absence.
* Congratulate them on happy occasions.
* Respect their privacy by not disturbing shared walls, drains, or courtyards. Avoid prying into their affairs, eavesdropping on conversations, and lowering your gaze towards their women.

> [!tip] summary
> 
> To uphold the rights of Muslim neighbors, refrain from harm, be friendly, visit during times of need, and respect their privacy.
