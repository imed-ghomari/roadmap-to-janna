---
type: process
initiative:
  - "[[Initiatives/worship/Zakat and charity and selflessness|Zakat and charity and selflessness]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Zakat and charity and selflessness](Initiatives/worship/Zakat%20and%20charity%20and%20selflessness.md)
