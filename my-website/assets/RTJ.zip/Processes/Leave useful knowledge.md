---
type: process
initiative:
- '[[Zakat and charity and selflessness]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: true
status: working
private: false
---

Link to [Zakat and charity and selflessness](Initiatives/worship/Zakat%20and%20charity%20and%20selflessness.md)
