---
type: process
initiative:
- '[[Praying]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: true
---

link to [Praying](Initiatives/worship/Praying.md)
