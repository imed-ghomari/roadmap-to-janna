---
type: process
initiative:
- '[[Seeking the lawful]]'
- '[[Parenting]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Seeking the lawful](Initiatives/worship/Seeking%20the%20lawful.md) and [Parenting](Initiatives/worship/Parenting.md)

Whenever there's suspicion, investigate the lawfulness of the matter before judging. For example, research food before consuming it or asking your local imam.

When in doubt, or if you can't access information in time, seek your heart. True sin is that which disturbs your heart. If accepting something feels wrong or creates unease within you, it's best to avoid it.
