---
type: process
initiative:
- '[[Remembering death]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: waiting
private: false
---

Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md)

Strive to be a muathin (if you can), to be from the ones who have a long neck on the day of qiyama.
