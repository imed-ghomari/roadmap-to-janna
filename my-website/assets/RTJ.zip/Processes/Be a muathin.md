---
type: process
initiative:
- '[[Remembering death]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md)

Strive to be a muathin (if you can) and live close to a mosque, to be from the ones who have a long neck on the day of qiyama.
