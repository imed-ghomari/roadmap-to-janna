---
type: process
initiative:
- '[[Following the sunnah]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: ongoing
private: false
---

Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md)

Some things to consider: strength training, cardio, stretching, and balancing
