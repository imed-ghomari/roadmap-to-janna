---
type: process
initiative:
- '[[Love of status and ostentation]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Love of status and ostentation](Initiatives/bad%20traits/Love%20of%20status%20and%20ostentation.md)

* Ward off Riya during the act when someone sees you by thinking that what they think doesn't matter; Allah matters. They are like animals or children; they don't benefit you in any way.
* Make sure not to stop the act, keep at it like you intended from the beginning.
* Make sure that if you increase in worship, it's only due to the removal of distractions and motivation of others, but test yourself to make sure.
