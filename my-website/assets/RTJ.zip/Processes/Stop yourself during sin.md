---
type: process
initiative:
- '[[Repentance]]'
- '[[Gluttony and lust]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: '1.1'
private: false
---

Linked to **[Repentance](Initiatives/good%20traits/Repentance.md):**

This is a critical step of repentance to be taken when you're about to commit a sin or during a sin. It focuses on the present moment and involves:

* **Stopping** sin and any associated negative thinking by recognizing the nature of the action and its consequences by reciting the associated verses and reflecting on the nearness of death.
* **Hating** the sin, not yourself. Shift focus away from self-criticism and use affirming, encouraging language. Have a growth mindset—believe in your ability to overcome shortcomings and return to the right path.
