---
type: process
initiative:
- '[[Zakat and charity and selflessness]]'
- '[[Following the sunnah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Zakat and charity and selflessness](Initiatives/worship/Zakat%20and%20charity%20and%20selflessness.md): even a smile can be considered a charity
* Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md): he used to smile without laughing loudly

> Prolonged amusement can numb your soul, which can lead to foolishness and headlessness