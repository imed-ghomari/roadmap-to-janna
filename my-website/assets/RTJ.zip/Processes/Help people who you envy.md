---
type: process
initiative:
- '[[Envy]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Envy](Initiatives/bad%20traits/Envy.md): Help people who are more blessed, be humble with them, praise them, and feel joy for them (if you can't help them physically, pray for them).