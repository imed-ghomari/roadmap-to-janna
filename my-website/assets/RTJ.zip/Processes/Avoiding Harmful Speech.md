---
type: process
initiative:
- '[[Loquaciousness]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

link to [Loquaciousness](Initiatives/bad%20traits/Loquaciousness.md)

Refrain from making ornamentations or exaggerations in speech. Do not use curse words, vulgar language, or obscenities. Avoid songs, poetry, or excessive joking/laughing that contain bad words or ridicule others.