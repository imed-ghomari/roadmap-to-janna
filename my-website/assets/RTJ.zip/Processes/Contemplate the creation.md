---
type: process
initiative:
- '[[Love]]'
- '[[Remembrance of allah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Love](Initiatives/good%20traits/Love.md): Reflect on the world and its attributes, and recognize that Allah possesses the qualities of the people you admire, but on a scale that surpasses humans. He is the source of all goodness and beauty.
* Link to [Remembrance of allah](Initiatives/worship/Remembrance%20of%20allah.md): Contemplate Allah's creations by observing nature and the beauty of this world. You can do this through documentaries or exploring places with natural surroundings.