---
type: process
initiative:
- '[[Seeking the lawful]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Seeking the lawful](Initiatives/worship/Seeking%20the%20lawful.md): Don't fear poverty; Allah is the sustainer. If you don't earn lawfully, your supplication won't be accepted.