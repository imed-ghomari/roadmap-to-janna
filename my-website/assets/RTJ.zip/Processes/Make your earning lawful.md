---
type: process
initiative:
- '[[Seeking the lawful]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Seeking the lawful](Initiatives/worship/Seeking%20the%20lawful.md): Don't fear poverty; Allah is the sustainer. If you don't earn lawfully, your supplication won't be accepted.
