---
type: process
initiative:
- '[[Asceticism]]'
- '[[Following the sunnah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Asceticism](Initiatives/good%20traits/Asceticism.md): allow yourself to have fun to recharge, as the nafs has a right over yourself
* Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md): Have fun the halal way by spending time with your spouse and children, pondering the creation of God, engaging in physical activities, consuming beneficial content, listening to nasheeds, and taking naps.