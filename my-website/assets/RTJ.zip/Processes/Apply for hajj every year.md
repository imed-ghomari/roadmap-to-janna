---
type: process
initiative:
- '[[Hajj]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Hajj](Initiatives/worship/Hajj.md)
