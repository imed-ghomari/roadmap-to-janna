---
type: process
initiative:
- '[[Seeking the lawful]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

link to [Seeking the lawful](Initiatives/worship/Seeking%20the%20lawful.md)

* If gifts are given without demand, one should accept them if they come from a good-willing person.
* Don't reject gifts or invitations simply due to uncertainty about their permissibility, particularly if doing so could cause offense or hurt feelings.
