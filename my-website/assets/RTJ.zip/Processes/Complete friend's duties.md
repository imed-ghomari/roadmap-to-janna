---
type: process
initiative:
- '[[Upholding the right of muslims]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md)

* **Fulfilling their needs:** Helping and fulfilling their requests, whenever possible.
* **Verbal support:** Expressing gratitude, consolation, and encouragement during difficult times.
* **Silence about dislikes:** Refraining from discussing or complaining about non-sinful behavior.
* **Speaking out:** Offering advice, guidance and admonishment.
* **Supplicating for them:** Praying for their well-being, both during life and after death.
* **Loyalty and sincerity:** Being honest, trustworthy, and not exploiting their status or wealth.
* **Avoiding overburdening:** Do not impose on them or make unreasonable requests.