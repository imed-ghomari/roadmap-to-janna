---
type: process
initiative:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Fasting](Initiatives/worship/Fasting.md): break with light food so you can wake up easily to pray tahajjud
