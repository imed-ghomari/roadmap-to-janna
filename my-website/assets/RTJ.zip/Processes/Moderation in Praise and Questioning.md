---
type: process
initiative:
  - "[[Initiatives/bad traits/Loquaciousness|Loquaciousness]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Loquaciousness](Initiatives/bad%20traits/Loquaciousness.md):

* Avoid carelessness in speaking about religion and excessive questioning about Allah's attributes out of doubt.
* If you know that the praise won't increase the person's self-admiration and pride, then you can praise him to encourage him, but make sure to avoid exaggeration, insincere affection, speculative statements, and pleasing a wrongdoer.
