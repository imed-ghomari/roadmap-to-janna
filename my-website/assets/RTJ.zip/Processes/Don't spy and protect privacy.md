---
type: process
initiative:
- '[[Commanding good and forbidding evil]]'
- '[[Upholding the right of muslims]]'
- '[[Parenting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

* Link to [Commanding good and forbidding evil](Initiatives/worship/Commanding%20good%20and%20forbidding%20evil.md): Avoid spying on others to identify and prevent wrongdoing.
* Link to [Upholding the right of Muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md):
	* Respect people's privacy. If you overhear a conversation unintentionally, consider covering your ear with headphones.
	* don't enter the house without permission, and stop at three times.
* Link to [Parenting](Initiatives/worship/Parenting.md): Protect children's privacy. Even within the same household, avoid entering their room without permission and give them space to be alone.
