---
type: process
initiative:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: waiting
private: false
---

link to [Fasting](Initiatives/worship/Fasting.md)
