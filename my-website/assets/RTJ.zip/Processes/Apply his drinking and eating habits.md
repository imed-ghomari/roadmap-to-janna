---
type: process
initiative:
- '[[Following the sunnah]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md):

* Drink, sitting down from a cup and breathing 3 times
* Eat slowly with 3 fingers on the ground, and if it's from the same bowl, eat from your side
