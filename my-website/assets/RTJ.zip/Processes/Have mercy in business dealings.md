---
type: process
initiative:
- '[[Anger]]'
- '[[Following the sunnah]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

Link to [Anger](Initiatives/bad%20traits/Anger.md) and [Following the sunnah](Initiatives/worship/Following%20the%20sunnah.md)

Because this is where people demand their rights most often, being merciful is very praiseworthy.
