---
type: process
initiative:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

link to [Fasting](Initiatives/worship/Fasting.md)

And if you have any missed days, make them up before the next Ramadan.
