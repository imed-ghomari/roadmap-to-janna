---
type: process
initiative:
  - "[[Initiatives/bad traits/Stinginess|Stinginess]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Stinginess](Initiatives/bad%20traits/Stinginess.md)

For example, for obligatory deeds requiring a lot of money (e.g. Hajj)
