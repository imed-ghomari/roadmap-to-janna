---
type: process
initiative:
- '[[Sincerity and truthfulness]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Sincerity and truthfulness](Initiatives/good%20traits/Sincerity%20and%20truthfulness.md)

In voluntary prayers and fasting, have multiple good intentions while doing one supplementary thing to have more rewards
