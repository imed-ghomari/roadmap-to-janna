---
type: process
initiative:
  - "[[Initiatives/good traits/Sincerity and truthfulness|Sincerity and truthfulness]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Sincerity and truthfulness](Initiatives/good%20traits/Sincerity%20and%20truthfulness.md)

In voluntary prayers and fasting, have multiple good intentions while doing one supplementary thing to have more rewards
