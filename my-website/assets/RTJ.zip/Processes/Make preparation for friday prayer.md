---
type: process
initiative:
- '[[Praying]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Praying](Initiatives/worship/Praying.md)

Complete Friday prayer by:

* Going early,
* Cleaning the body and beautifying it with perfume
* Reading surat kahf
