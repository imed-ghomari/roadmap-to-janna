---
type: process
initiative:
  - "[[Initiatives/worship/Praying|Praying]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Praying](Initiatives/worship/Praying.md)

Complete Friday prayer by:

* Going early,
* Cleaning the body and beautifying it with perfume
* Reading surat kahf
