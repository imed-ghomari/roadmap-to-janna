---
type: process
initiative:
- '[[Upholding the right of muslims]]'
- '[[Remembering death]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Upholding the right of muslims](Initiatives/worship/Upholding%20the%20right%20of%20muslims.md):
	* Who? It can stop at uncles and aunt from the mother and the father, though you can extend it as you see fit.
	* What to do? Ask about their news, be aware of their situation by calling or meeting, and try to give them your time.
	* Exception? This should be done **especially** if they don't treat you well or severed contact with you.
* Link to [Remembering death](Initiatives/good%20traits/Remembering%20death.md): Protecting this specific amana (family ties) will help you get back up when you're about to fall from the Sirat!

> Keeping ties increases wealth and lifespan