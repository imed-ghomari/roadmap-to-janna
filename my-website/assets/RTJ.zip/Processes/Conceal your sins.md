---
type: process
initiative:
  - "[[Initiatives/bad traits/Love of status and ostentation|Love of status and ostentation]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: 
dependency: ""
step: ""
---

Link to [Love of status and ostentation](Initiatives/bad%20traits/Love%20of%20status%20and%20ostentation.md)

Don't confuse not seeking status with revealing your sins. You should conceal your sins because Allah shielded you, but don't make it appear as if you are better than what you seem, either. If you publicize your sins, Allah will not cover you in the day of iqama.
