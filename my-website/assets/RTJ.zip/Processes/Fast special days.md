---
type: process
initiative:
- '[[Fasting]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

link to [Fasting](Initiatives/worship/Fasting.md)

* tasu'a
* 3achura
* shawwal
* dulhijjah
* arafa
