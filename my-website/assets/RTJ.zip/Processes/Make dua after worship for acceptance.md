---
type: process
initiative:
- '[[Fear and hope]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

* Link to [Pride and Self Admiration and Humility](Initiatives/bad%20traits/Pride%20and%20self%20admiration%20and%20humility.md): It is to understand that your deeds might not get accepted, so don't get pompous because of them
* Link to [Fear and Hope](Initiatives/good%20traits/Fear%20and%20hope.md): Is to Make dua after each prayer and fasting, to accept your worship out of fear for your negligence

A good application of this is the dua said after Salat Fajr, "اَللّٰهُمَّ إِنِّيْ أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا."
