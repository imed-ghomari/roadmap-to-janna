---
type: process
initiative:
  - "[[Initiatives/worship/Managing spouse|Managing spouse]]"
working: false
due: ""
duration: 
recurrence: ""
start: ""
waiting: false
review: ""
file: ""
context: ""
dependency: ""
step: ""
---

Link to [Managing spouse](Initiatives/worship/Managing%20spouse.md)

1. Turn away from the qibla (direction faced during prayer) and begin with foreplay and kissing. After climax, facilitate your partner's climax, as it may not occur as quickly as your own. Do not engage in intercourse during menstruation. And at the end, perform Ghusl.
2. Maintain personal hygiene and beautify yourself before and in general to be more appealing to your partner.
 
