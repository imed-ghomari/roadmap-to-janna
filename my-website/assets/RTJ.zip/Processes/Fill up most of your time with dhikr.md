---
type: process
initiative:
- '[[Remembrance of allah]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: working
private: false
---

Link to [Remembrance of allah](Initiatives/worship/Remembrance%20of%20allah.md)

Strive to maintain a state of gratitude or repentance at all times, as you may be using Allah's blessings in beneficial or detrimental ways. Engage in both to encompass all possibilities. When your lips are dry, perform silent dhikr by reciting "La ilaha illallah" silently in your mouth.

## Suitable Occasions for Remembrance

* While waiting in line or for appointments
* When performing routine tasks (such as driving, cleaning, cooking, exercising, or minor maintenance)
* During moments of rest (when taking breaks)
* While going out or walking
