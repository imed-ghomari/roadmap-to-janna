---
type: process
initiative:
- '[[Envy]]'
- '[[Managing spouse]]'
working: false
due: ''
duration: null
recurrence: ''
start: ''
waiting: false
review: ''
file: ''
context: ''
dependency: ''
step: ''
---

* Link to [Envy](Initiatives/bad%20traits/Envy.md): Good envy or jealousy is to be jealous over your spouse
* Link to [Managing spouse](Initiatives/worship/Managing%20spouse.md), in regards to women, give her freedom in:
	1. Her money (spend as she likes)
	2. She can have a job given that she takes care of her side of the obligations
	3. Observing moderation in jealousy (not being unmindful of the first steps of a destructive end but not going overboard with suspicion either)