---
type: process
initiative:
- '[[Praying]]'
due: ''
recurrence: ''
start: ''
context: ''
dependency: ''
delay: false
status: waiting
private: false
---

Link to [Praying](Initiatives/worship/Praying.md): Dua is an important nafil prayer that begins after sunrise and ends at noon.
