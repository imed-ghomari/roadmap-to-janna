---
status: designed
start: ''
objective: worship well
dependency: ''
sidebar_label: Praying
outcome: ''
type: domain
data: null
---

## Obligatory Prayer Requirements

* **The first matter** is being vigilant about ritual purification by [performing ablution](Processes/Have%20multiple%20intentions%20in%20worship%20acts.md) before the prayer. The objective of purifying clothes and the body is to purify the heart. Remember to consider each body member and its connection to the acts you are washing out.
* **The second matter** is to be vigilant about the prayer's recommended acts, outer practices, remembrances, and glorifications.
	* [Pray obligatory prayers on time or make them up](Processes/Pray%20obligatory%20prayers%20on%20time%20or%20make%20them%20up.md).
	* Pray by following the rules (roukn, sunna, mustahab).
	* Follow the rules based on your madhab for completing your prayer when joining late in the congregation.
	* Follow the rules based on your madhab regarding sujud tilawah (prostrating during the recitation of the Quran when praying).
	* [Change suwar](Processes/Focus%20during%20prayer.md) in each prayer following the sunnah.
	* Use most or all known supplications in each part of the salah. You can find them in the supplications applications.
	* Pray Jumu'ah prayer, wash, [go to the mosque early](Processes/Make%20preparation%20for%20friday%20prayer.md), and read Surah Kahf.
	* Pray in a congregation or [in the mosque](Processes/Pray%20in%20the%20mosque.md) whenever possible, strive to lead salah, and the one who leads should be the most knowledgeable of the Quran.
	* Listen to the athan, [respond](Processes/Respond%20to%20call%20of%20prayer.md), and think of it as the call on the Resurrection Day.
* **The third matter** is to be [vigilant regarding the spirit of the prayer](Processes/Focus%20during%20prayer.md), which means having sincerity, presence of heart throughout its entirety, and for the heart to take on the qualities of the prayer's inner meanings during the act. Among the things that bring life to the prayer:
	* Understand the words by fighting external distractions through prepping the environment and internal distraction through redirecting focus on the recitations.
	* Glorify and revere Allah by knowing His Sublimity and Might, and understanding the worthlessness of the self.
	* Cultivate hope (_raja_) and fear (_kawf_) during prayer.
	* Feel shame, which arises out of service and knowledge of neglect.

## Supplementary Prayers

### Conditions Of Voluntary Prayers

* You can pray seated in voluntary prayers but won't get the full reward.
* Try to pray voluntary prayers in [seclusion](Processes/Hide%20your%20good%20deeds.md) to get the full reward (hide your good deeds like you hide your evil deeds).

### Types Of Voluntary Prayers

* [Pray 12 daily voluntary prayers](Processes/Pray%2012%20daily%20nawafil%20prayers.md).
* [Pray the dua prayer](Processes/Pray%20the%20dua%20prayer.md) (2 rakat between sunrise and Duhr prayer).
* Pray the qiyam lay or [tahajud prayer](Processes/Pray%20tahajud%20prayer.md) (night vigil prayer), which is considered the best prayer after the obligatory prayer.
* When you feel grateful, [pray the shukr nafil prayer](Processes/Pray%20chukr%20nafil%20prayer.md).
* When you want to repent, [pray the repentance nafil prayer](Processes/regret%20and%20prevent.md).
* When you want to make a choice, [pray the istikhara nafil prayer](Processes/Make%20istikhara%20when%20choosing.md).
* Other voluntary prayers are [rain, funeral, tasbih, eclipse, eid, taraweeh](Processes/Pray%20additional%20voluntary%20prayers.md), and 2 rakat when entering the mosque.